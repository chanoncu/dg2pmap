define({
  "map": {
    "error": "يتعذر إنشاء الخريطة"
  },
  "tools": {
    "search": {
      "error": "تعذر العثور على الموقع",
      "notWhatYouWanted": "أليس هذا ما تريده؟",
      "selectAnother": "تحديد موقع آخر",
      "currentLocation": "الموقع الحالي",
      "title": "الموقع"
    },
    "legend": "وسيلة إيضاح",
    "about": "نبذة عن"
  }
});