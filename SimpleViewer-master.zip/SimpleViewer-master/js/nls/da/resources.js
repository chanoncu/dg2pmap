define({
  "map": {
    "error": "Kan ikke oprette kort"
  },
  "tools": {
    "search": {
      "error": "Placeringen blev ikke fundet",
      "notWhatYouWanted": "Var det ikke det, du ville?",
      "selectAnother": "Vælg et andet sted",
      "currentLocation": "Nuværende placering",
      "title": "Placering"
    },
    "legend": "Signaturforklaring",
    "about": "Om"
  }
});