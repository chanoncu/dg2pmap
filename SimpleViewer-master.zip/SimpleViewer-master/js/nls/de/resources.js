define({
  "map": {
    "error": "Karte kann nicht erstellt werden"
  },
  "tools": {
    "search": {
      "error": "Position wurde nicht gefunden",
      "notWhatYouWanted": "Nicht das gewünschte Ergebnis?",
      "selectAnother": "Andere Position auswählen",
      "currentLocation": "Aktuelle Position",
      "title": "Position"
    },
    "legend": "Legende",
    "about": "Informationen"
  }
});