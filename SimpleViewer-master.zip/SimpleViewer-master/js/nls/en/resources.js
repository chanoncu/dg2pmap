define(
   ({
        map: {
            error: "Unable to create map"
        }, 
        tools: {
        	legend: "Legend",
        	 about: "About"
        }
    })
   
);