define({
  "map": {
    "error": "Kaardi loomine ebaõnnestus"
  },
  "tools": {
    "search": {
      "error": "Asukohta ei leitud",
      "notWhatYouWanted": "Ei ole see, mida soovisid?",
      "selectAnother": "Vali muu asukoht",
      "currentLocation": "Praegune asukoht",
      "title": "Asukoht"
    },
    "legend": "Legendiga kaart",
    "about": "Info"
  }
});