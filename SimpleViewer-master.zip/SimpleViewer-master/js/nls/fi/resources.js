define({
  "map": {
    "error": "Karttaa ei voi luoda"
  },
  "tools": {
    "search": {
      "error": "Sijaintia ei löytynyt",
      "notWhatYouWanted": "Etkö löytänyt etsimääsi?",
      "selectAnother": "Valitse toinen sijainti",
      "currentLocation": "Nykyinen sijainti",
      "title": "Sijainti"
    },
    "legend": "Selite",
    "about": "Tietoja"
  }
});