define({
  "map": {
    "error": "Impossible de créer la carte"
  },
  "tools": {
    "search": {
      "error": "Emplacement introuvable",
      "notWhatYouWanted": "Ce n'est pas ce que vous vouliez ?",
      "selectAnother": "Sélectionnez un autre emplacement",
      "currentLocation": "Emplacement actuel",
      "title": "Emplacement"
    },
    "legend": "Légende",
    "about": "A propos"
  }
});