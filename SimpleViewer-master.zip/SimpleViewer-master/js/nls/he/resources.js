define({
  "map": {
    "error": "לא ניתן ליצור מפה"
  },
  "tools": {
    "search": {
      "error": "לא ניתן למצוא מיקום",
      "notWhatYouWanted": "לא מה שחיפשת?",
      "selectAnother": "בחר מיקום אחר",
      "currentLocation": "מיקום נוכחי",
      "title": "מיקום"
    },
    "legend": "מקרא",
    "about": "אודות"
  }
});