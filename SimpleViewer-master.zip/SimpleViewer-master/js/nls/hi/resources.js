define({
  "map": {
    "error": "मानचित्र बनाने में अक्षम"
  },
  "tools": {
    "search": {
      "error": "स्थान नहीं मिल सका",
      "notWhatYouWanted": "वह नहीं है जो आपने चाहा?",
      "selectAnother": "अन्य स्थान चुनें",
      "currentLocation": "वर्तमान स्थान",
      "title": "स्थान"
    },
    "legend": "लीजेंड",
    "about": "बारे में"
  }
});