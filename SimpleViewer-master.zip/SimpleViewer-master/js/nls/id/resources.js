define({
  "map": {
    "error": "Tidak dapat membuat peta"
  },
  "tools": {
    "search": {
      "error": "Lokasi tidak dapat ditemukan",
      "notWhatYouWanted": "Bukan yang Anda inginkan?",
      "selectAnother": "Pilih lokasi lain",
      "currentLocation": "Lokasi Saat ini",
      "title": "Lokasi"
    },
    "legend": "Legenda",
    "about": "Tentang"
  }
});