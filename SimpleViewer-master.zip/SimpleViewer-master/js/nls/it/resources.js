define({
  "map": {
    "error": "Impossibile creare la mappa"
  },
  "tools": {
    "search": {
      "error": "Posizione non trovata",
      "notWhatYouWanted": "Non è quanto desiderato?",
      "selectAnother": "Selezionare un'altra posizione",
      "currentLocation": "Posizione corrente",
      "title": "Posizione"
    },
    "legend": "Legenda",
    "about": "Informazioni su"
  }
});