define({
  "map": {
    "error": "Žemėlapio sukurti nepavyko"
  },
  "tools": {
    "search": {
      "error": "Vietos surasti nepavyko",
      "notWhatYouWanted": "Ne tai ko norėjote?",
      "selectAnother": "Pasirinkite kitą vietą",
      "currentLocation": "dabartinė vieta",
      "title": "Vieta"
    },
    "legend": "Legenda",
    "about": "Apie"
  }
});