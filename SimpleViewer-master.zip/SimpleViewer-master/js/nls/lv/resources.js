define({
  "map": {
    "error": "Nevar izveidot karti"
  },
  "tools": {
    "search": {
      "error": "Izvietojumu nevarēja atrast",
      "notWhatYouWanted": "Vēlējāties kaut ko citu?",
      "selectAnother": "Izvēlieties citu izvietojumu",
      "currentLocation": "Pašreizējais izvietojums",
      "title": "Izvietojums"
    },
    "legend": "Apzīmējumi",
    "about": "Par"
  }
});