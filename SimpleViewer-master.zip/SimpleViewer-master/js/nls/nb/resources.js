define({
  "map": {
    "error": "Kan ikke opprette kart"
  },
  "tools": {
    "search": {
      "error": "Finner ikke lokasjonen",
      "notWhatYouWanted": "Ikke den du ville ha?",
      "selectAnother": "Velg en annen lokasjon",
      "currentLocation": "Gjeldende lokasjon",
      "title": "Lokasjon"
    },
    "legend": "Tegnforklaring",
    "about": "Om"
  }
});