define({
  "map": {
    "error": "Kaart kan niet gemaakt worden"
  },
  "tools": {
    "search": {
      "error": "Locatie is niet gevonden",
      "notWhatYouWanted": "Niet wat u wilde?",
      "selectAnother": "Een andere locatie selecteren",
      "currentLocation": "Huidige locatie",
      "title": "Locatie"
    },
    "legend": "Legenda",
    "about": "Info"
  }
});