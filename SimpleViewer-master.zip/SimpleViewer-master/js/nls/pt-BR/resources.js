define({
  "map": {
    "error": "Não foi possível criar o mapa"
  },
  "tools": {
    "search": {
      "error": "Não foi possível encontrar o local",
      "notWhatYouWanted": "Não é o que você desejava?",
      "selectAnother": "Selecionar outro local",
      "currentLocation": "Local atual",
      "title": "Local"
    },
    "legend": "Legenda",
    "about": "Sobre"
  }
});