define({
  "map": {
    "error": "Impossível criar mapa"
  },
  "tools": {
    "search": {
      "error": "A localização não pode ser encontrada",
      "notWhatYouWanted": "Não é o que queria?",
      "selectAnother": "Selecionar outra localização",
      "currentLocation": "Localização Atual",
      "title": "localização"
    },
    "legend": "Legenda",
    "about": "Sobre"
  }
});