define({
  "map": {
    "error": "Nu se poate crea harta"
  },
  "tools": {
    "search": {
      "error": "Locaţia nu a putut fi găsită",
      "notWhatYouWanted": "Nu este ce doreaţi?",
      "selectAnother": "Selectaţi altă locaţie",
      "currentLocation": "Locaţie curentă",
      "title": "Locaţie"
    },
    "legend": "Legendă",
    "about": "Despre"
  }
});