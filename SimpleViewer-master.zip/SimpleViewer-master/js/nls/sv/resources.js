define({
  "map": {
    "error": "Det gick inte att skapa kartan"
  },
  "tools": {
    "search": {
      "error": "Det gick inte att hitta platsen",
      "notWhatYouWanted": "Är det inte vad du vill ha?",
      "selectAnother": "Välj en annan plats",
      "currentLocation": "Aktuell plats",
      "title": "Plats"
    },
    "legend": "Teckenförklaring",
    "about": "Om"
  }
});