define({
  "map": {
    "error": "ไม่สามารถสร้างแผนที่ได้"
  },
  "tools": {
    "search": {
      "error": "ไม่พบตำแหน่งนี้",
      "notWhatYouWanted": "ไม่ใช่สิ่งที่คุณต้องการ?",
      "selectAnother": "เลือกที่ตั้งอื่น",
      "currentLocation": "ตำแหน่งปัจจุบัน",
      "title": "ตำแหน่ง"
    },
    "legend": "คำอธิบายสัญลักษณ์",
    "about": "เกี่ยวกับ"
  }
});