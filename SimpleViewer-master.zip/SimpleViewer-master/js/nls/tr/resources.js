define({
  "map": {
    "error": "Harita oluşturulamıyor"
  },
  "tools": {
    "search": {
      "error": "Konum bulunamadı",
      "notWhatYouWanted": "İstediğiniz bu değil mi?",
      "selectAnother": "Başka bir konum seç",
      "currentLocation": "Mevcut Konum",
      "title": "Konum"
    },
    "legend": "Gösterim",
    "about": "Yaklaşık"
  }
});