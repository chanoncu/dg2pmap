define({
  "map": {
    "error": "Không thể tạo bản đồ"
  },
  "tools": {
    "search": {
      "error": "Không thể tìm thấy vị trí",
      "notWhatYouWanted": "Không phải cái bạn muốn?",
      "selectAnother": "Chọn một vị trí khác",
      "currentLocation": "Vị trí hiện tại",
      "title": "Vị trí"
    },
    "legend": "Chú giải",
    "about": "Về"
  }
});