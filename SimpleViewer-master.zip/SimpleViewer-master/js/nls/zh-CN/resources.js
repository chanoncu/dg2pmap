define({
  "map": {
    "error": "无法创建地图"
  },
  "tools": {
    "search": {
      "error": "无法找到位置",
      "notWhatYouWanted": "不是您想要的位置?",
      "selectAnother": "选择其他位置",
      "currentLocation": "当前位置",
      "title": "位置"
    },
    "legend": "图例",
    "about": "关于"
  }
});