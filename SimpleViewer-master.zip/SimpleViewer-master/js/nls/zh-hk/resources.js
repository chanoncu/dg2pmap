define({
  "map": {
    "error": "無法建立地圖"
  },
  "tools": {
    "search": {
      "error": "無法找到位置",
      "notWhatYouWanted": "不是您想要的位置?",
      "selectAnother": "選擇其他位置",
      "currentLocation": "目前位置",
      "title": "位置"
    },
    "legend": "圖例",
    "about": "關於"
  }
});